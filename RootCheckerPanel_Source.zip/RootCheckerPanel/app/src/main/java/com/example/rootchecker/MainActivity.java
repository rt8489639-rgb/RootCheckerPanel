package com.example.rootchecker;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;

public class MainActivity extends Activity {
    private TextView status;
    private TextView details;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(12, 16, 18));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(42), dp(24), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("ROOT CHECKER");
        title.setTextColor(Color.rgb(0, 255, 145));
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("ANDROID DEVICE DIAGNOSTICS");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, dp(28));
        root.addView(subtitle, matchWrap());

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(24), dp(20), dp(24));
        panel.setBackgroundColor(Color.rgb(29, 36, 38));
        root.addView(panel, matchWrap());

        status = new TextView(this);
        status.setText("STATUS: NOT CHECKED");
        status.setTextColor(Color.WHITE);
        status.setTextSize(20);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        status.setGravity(Gravity.CENTER);
        panel.addView(status, matchWrap());

        details = new TextView(this);
        details.setText("Tap the button to scan common root indicators.");
        details.setTextColor(Color.LTGRAY);
        details.setTextSize(14);
        details.setPadding(0, dp(18), 0, dp(22));
        panel.addView(details, matchWrap());

        Button check = new Button(this);
        check.setText("CHECK ROOT");
        check.setTextColor(Color.BLACK);
        check.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                Color.rgb(0, 255, 145)));
        panel.addView(check, matchWrap());
        check.setOnClickListener(v -> runCheck());

        TextView note = new TextView(this);
        note.setText("Note: This is a basic indicator scan, not a guaranteed root verdict. "
                + "Some rooted devices hide these files, and some unrooted devices may contain "
                + "test indicators. This app does not modify your device or bypass game security.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private void runCheck() {
        String[] paths = {
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/su",
            "/system/app/Superuser.apk",
            "/data/adb/magisk",
            "/sbin/.magisk"
        };

        StringBuilder found = new StringBuilder();
        for (String path : paths) {
            if (new File(path).exists()) {
                if (found.length() > 0) found.append("\n");
                found.append("• ").append(path);
            }
        }

        boolean testKeys = Build.TAGS != null && Build.TAGS.contains("test-keys");
        if (testKeys) {
            if (found.length() > 0) found.append("\n");
            found.append("• Build tags contain test-keys");
        }

        if (found.length() > 0) {
            status.setText("POSSIBLE ROOT INDICATORS FOUND");
            status.setTextColor(Color.rgb(255, 190, 60));
            details.setText(found.toString()
                    + "\n\nThis is not proof of root access; verify with a trusted device-management tool.");
        } else {
            status.setText("NO COMMON INDICATORS FOUND");
            status.setTextColor(Color.rgb(0, 255, 145));
            details.setText("No common root files or test-key indicator were detected. "
                    + "Root may still be present but hidden.");
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
