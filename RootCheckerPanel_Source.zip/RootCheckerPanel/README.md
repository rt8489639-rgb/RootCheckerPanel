# Root Checker Panel

A simple Android Studio Java app that checks for common root-related file indicators and test-key build tags.

## Build an APK
1. Install Android Studio and the Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Wait for Gradle sync to finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Important limitations
- This is a basic heuristic scan, not definitive proof of root status.
- Root-hiding tools can make a rooted device appear unrooted.
- Some custom or test builds can trigger indicators without conventional root access.
- The app does not request root privileges, change system files, or bypass Free Fire/game security.
